/*
 * Copyright (c) 2016-present, salesforce.com, inc.
 * All rights reserved.
 * Redistribution and use of this software in source and binary forms, with or
 * without modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * - Neither the name of salesforce.com, inc. nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission of salesforce.com, inc.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

var path = require('path'),
    shelljs = require('shelljs');

var VERSION= '13.2.0';

module.exports = {
    version: VERSION,

    tools: {
        git: {
            checkCmd: 'git --version',
            minVersion: '2.13'
        },
        node: {
            checkCmd: 'node --version',
            minVersion: '20'
        },
        npm: {
            checkCmd: 'npm -v',
            minVersion: '10'
        },
        yarn: {
            checkCmd: 'yarn -v',
            minVersion: '1.22'
        },
        tsc: {
            checkCmd: 'tsc  -v',
            minVersion: '4.1.2'
        },
        pod: {
            checkCmd: 'pod --version',
            minVersion: '1.8.0'
        },
        cordova: {
            checkCmd: 'cordova -v',
            pluginRepoUri: 'https://github.com/forcedotcom/SalesforceMobileSDK-CordovaPlugin#dev',    // dev
            minVersion: '13.0.0',
//             pluginRepoUri: 'salesforce-mobilesdk-cordova-plugin@v' + VERSION, // GA
            platformVersion: {
                ios: '7.1.1',
                android: '14.0.1'
            }
        },
        sf: {
            checkCmd: 'sf -v',
            minVersion: '2.0.0'
        }    
    },

    ides: {
        ios: 'XCode',
        android: 'Android Studio'
    },

    templatesRepoUri: 'https://github.com/forcedotcom/SalesforceMobileSDK-Templates#dev',    // dev
//     templatesRepoUri: 'https://github.com/forcedotcom/SalesforceMobileSDK-Templates#v' + VERSION, // GA

    forceclis: {
        forceios: {
            name: 'forceios',
            topic: 'ios',
            purpose: 'an iOS native mobile application',
            dir: 'ios',
            platforms: ['ios'],
            toolNames: ['git', 'node', 'npm', 'pod'],
            appTypes: ['native_swift', 'native'],
            appTypesToPath: {
                'native': 'iOSNativeTemplate',
                'native_swift': 'iOSNativeSwiftTemplate'
            },
            commands: ['create', 'createwithtemplate', 'version', 'listtemplates', 'describetemplate', 'checkconfig']
        },
        forcedroid: {
            name: 'forcedroid',
            topic: 'android',
            purpose: 'an Android native mobile application',
            dir: 'android',
            platforms: ['android'],
            toolNames: ['git', 'node', 'npm'],
            appTypes: ['native_kotlin', 'native'],
            appTypesToPath: {
                'native': 'AndroidNativeTemplate',
                'native_kotlin': 'AndroidNativeKotlinTemplate'
            },
            commands: ['create', 'createwithtemplate', 'version', 'listtemplates', 'describetemplate', 'checkconfig']
        },
        forcehybrid: {
            name: 'forcehybrid',
            topic: 'hybrid',
            purpose: 'a hybrid mobile application',
            dir: 'hybrid',
            platforms: ['ios', 'android'],
            toolNames: ['git', 'node', 'npm', 'cordova', 'sf'],
            appTypes: ['hybrid_local', 'hybrid_remote'],
            appTypesToPath: {
                'hybrid_local': 'HybridLocalTemplate',
                'hybrid_remote': 'HybridRemoteTemplate'
            },
            commands: ['create', 'createwithtemplate', 'version', 'listtemplates', 'describetemplate', 'checkconfig']
        },
        forcereact: {
            name: 'forcereact',
            topic: 'reactnative',
            purpose: 'a React Native mobile application',
            dir: 'react',
            platforms: ['ios', 'android'],
            toolNames: ['git', 'node', 'yarn', 'tsc', 'pod'],
            appTypes: ['react_native_typescript', 'react_native'],
            appTypesToPath: {
                'react_native': 'ReactNativeTemplate',
                'react_native_typescript': 'ReactNativeTypeScriptTemplate'
            },
            commands: ['create', 'createwithtemplate', 'version', 'listtemplates', 'describetemplate', 'checkconfig']
        }
    },
    
    args: {
        platform: {
            name: 'platform',
            'char': 'p',
            description: cli => 'comma-separated list of platforms (' + cli.platforms.join(', ') + ')',
            longDescription: cli => 'A comma-separated list of one or more platforms you support. The script creates a project for each platform you select. Available options are ' + cli.platforms.join(', ') + '.',
            prompt: cli => 'Enter the target platform(s) separated by commas (' + cli.platforms.join(', ') + '):',
            error: cli => val => 'Platform(s) must be in ' + cli.platforms.join(', '),
            validate: cli => val => !val.split(",").some(p=>cli.platforms.indexOf(p) == -1),
            promptIf: cli => otherArgs => cli.platforms.length > 1,
            type: 'string'
        },
        appType: {
            name:'apptype',
            'char':'t',
            description: cli => cli.appTypes.length > 1 ? 'application type (' + cli.appTypes.join(' or ') + ', leave empty for ' + cli.appTypes[0] + ')' : '',
            longDescription: cli => cli.appTypes.length > 1 ? 'You can choose one of the following types of applications: ' + cli.appTypes.join(', ') + '.' : '',
            prompt: cli => 'Enter your application type (' + cli.appTypes.join(' or ') + ', leave empty for ' + cli.appTypes[0] + '):',
            error: cli => val => 'App type must be ' + cli.appTypes.join(' or ') + '.',
            validate: cli => val => val === undefined || val === '' || cli.appTypes.indexOf(val) >=0,
            promptIf: cli => otherArgs => cli.appTypes.length > 1,
            required: false,
            type: 'string'
        },
        templateRepoUri: {
            name:'templaterepouri',
            'char': 'r',
            description:'template repo URI or Mobile SDK template name',
            longDescription: 'The URI of a repository that contains the template application to be used as the basis of your new app or simply the name of a Mobile SDK template.',
            prompt: 'Enter URI of repo containing template application or a Mobile SDK template name:',
            error: cli => val => 'Invalid value for template repo uri: \'' + val + '\'.',
            validate: cli => val => /^\S+$/.test(val),
            promptIf: otherArgs => !otherArgs.templatesource,
            required: false,
            type: 'string'
        },
        templateSource: {
            name: 'templatesource',
            'char': 'S',
            description: 'git repo URL (optionally with #branch) or local path to a templates suite (root must contain templates.json)',
            longDescription: 'Location of a suite of templates. Can be a git URL with optional #branch suffix or a local filesystem path whose root contains templates.json.',
            prompt: 'Enter git URL or local path to your templates suite:',
            error: cli => val => 'Invalid value for template source: \'' + val + '\'.',
            validate: cli => val => /\S+/.test(val),
            // Process only when explicitly provided to avoid prompting during interactive flows
            promptIf: otherArgs => typeof otherArgs.templatesource !== 'undefined',
            required: false,
            type: 'string'
        },
        template: {
            name: 'template',
            'char': 'm',
            description: 'template name within the templates suite (e.g. ReactNativeTemplate)',
            longDescription: 'Name of the template to use from the suite specified by --templatesource. Should match the directory name or the path field in templates.json.',
            prompt: 'Enter the template name from your template source:',
            error: cli => val => 'Invalid value for template: \'' + val + '\'.',
            validate: cli => val => /\S+/.test(val),
            // Only prompt for template when a templatesource is provided
            promptIf: otherArgs => !!otherArgs.templatesource,
            required: false,
            type: 'string'
        },
        appName: {
            name: 'appname',
            'char': 'n',
            description: 'application name',
            longDescription: 'A name for the app that conforms to the naming requirements for the platform.',
            prompt: 'Enter your application name:',
            error: cli => val => 'Invalid value for application name: \'' + val + '\'.',
            validate: cli => val => (cli.platforms.indexOf('ios') != -1 ? /^[^\s-]+$/ : /^\S+$/).test(val),
            type: 'string'
        },
        packageName: {
            name: 'packagename',
            'char': 'k',
            description: 'app package identifier (e.g. com.mycompany.myapp)',
            longDescription: 'A string in reverse internet domain format that identifies your app\'s package or bundle. For example, "com.mycompany.myapp".',
            prompt: 'Enter your package name:',
            error: cli => val => '\'' + val + '\' is not a valid package name.',
            validate: cli => val => /^[a-z]+[a-z0-9_]*(\.[a-z]+[a-z0-9_-]*)*$/.test(val),
            type: 'string'
        },
        organization: {
            name: 'organization',
            'char': 'o',
            description: 'organization name (your company\'s/organization\'s name)',
            longDescription: 'The name of your company or organization. This string is user-defined and may contain spaces and punctuation.',
            prompt: 'Enter your organization name (Acme, Inc.):',
            error: cli => val => 'Invalid value for organization: \'' + val + '\'.',
            validate: cli => val => /\S+/.test(val),
            type: 'string'
        },
        outputDir: {
            name:'outputdir',
            'char':'d',
            description:'output directory (leave empty for current directory)',
            longDescription: 'The local path for your new project. If this path points to an existing directory, that directory must be empty. If you don\'t specify a value, the script creates the app in the current directory.',
            prompt: 'Enter output directory for your app (leave empty for the current directory):',
            error: cli => val => 'Invalid value for output directory (directory must not already exist): \'' + val + '\'.',
            validate: cli => val => val === undefined || val === '' || !shelljs.test('-e', path.resolve(val)),
            required:false,
            type: 'string'
        },
        startPage: {
            name:'startpage',
            'char':'s',
            description:'app start page (the start page of your remote app; required for hybrid_remote apps only)',
            longDescription: 'For hybrid remote apps only, specify the relative server path to your Visualforce start page. This relative path always discards the Salesforce instance and domain name and starts with "apex/".',
            prompt: 'Enter the start page for your app:',
            error: cli => val => 'Invalid value for start page: \'' + val + '\'.',
            validate: cli => val => /\S+/.test(val),
            required: false,
            promptIf: otherArgs => otherArgs.apptype === 'hybrid_remote',
            type: 'string'
        },
        configPath: {
            name:'configpath',
            'char': 'p',
            description:'path to store or syncs config to validate',
            longDescription:'Path to the store or syncs config file to validate.',
            error: cli => val => 'Config file not found: \'' + val + '\'.',
            prompt: 'Enter the path of the store or syncs config to validate:',
            validate: cli => val => shelljs.test('-e', path.resolve(val)),
            required: true,
            type: 'string'
        },
        configType: {
            name:'configtype',
            'char': 't',
            description:'type of config to validate (store or syncs)',
            longDescription:'Type of config to validate (store or syncs).',
            error: cli => val => 'Invalid config type: \'' + val + '\'.',
            prompt: 'Enter the type of the config to validate (store or syncs):',
            validate: cli => val => val === 'store' || val === 'syncs',
            required: true,
            type: 'string'
        },
        // Private args
        verbose: {
            name: 'verbose',
            'char': 'v',
            description: 'increase information output',
            hasValue: false,
            required: false,
            type: 'boolean',
            hidden: true
        },
        pluginRepoUri: {
            name: 'pluginrepouri',
            description: 'supply a plugin repository uri',
            'char': 'v',
            error: cli => val => 'Invalid value for plugin repo uri: \'' + val + '\'.',
            validate: cli => val => /.*/.test(val),
            required: false,
            type: 'string',
            hidden: true
        },
	    sdkDependencies: {
            name: 'sdkdependencies',
            description: 'override sdk dependencies',
            'char': 'd',
            error: cli => val => 'Invalid value for sdk dependencies: \'' + val + '\'.',
            validate: cli => val => /.*/.test(val),
            required: false,
            type: 'string',
            hidden: true
	        },
        doc: {
            name: 'doc',
            'char': 'D',
            description: 'include verbose documentation from template.json files',
            longDescription: 'When specified, includes detailed metadata from each template\'s template.json file if available (displayName, description, useCase, features, complexity).',
            prompt: null,
            error: cli => val => 'Invalid value for doc flag: \'' + val + '\'.',
            validate: cli => val => true, // Boolean flag, no validation needed
            required: false,
            type: 'boolean',
            hidden: false
        },
        json: {
            name: 'json',
            'char': 'j',
            description: 'output response in JSON format',
            longDescription: 'When specified, outputs the response in JSON format instead of human-readable text. Useful for programmatic consumption.',
            prompt: null,
            error: cli => val => 'Invalid value for json flag: \'' + val + '\'.',
            validate: cli => val => true, // Boolean flag, no validation needed
            required: false,
            type: 'boolean',
            hidden: false
        },
        consumerKey: {
            name: 'consumerkey',
            'char': 'c',
            description: 'OAuth consumer key for the Salesforce External Client App or Connected App',
            longDescription: 'The OAuth consumer key (client ID) for your Salesforce External Client App or Connected App. When provided, this will be automatically configured in the generated app.',
            prompt: 'Enter your OAuth consumer key (leave empty to manually configure this value in the project\'s bootconfig file):',
            error: cli => val => 'Invalid value for consumer key: \'' + val + '\'.',
            validate: cli => val => val === undefined || val === '' || /\S+/.test(val),
            required: false,
            type: 'string'
        },
        callbackURL: {
            name: 'callbackurl',
            'char': 'u',
            description: 'OAuth callback URL for the Salesforce External Client App or Connected App',
            longDescription: 'The OAuth callback URL (redirect URI) for your Salesforce External Client App or Connected App. When provided, this will be automatically configured in the generated app.',
            prompt: 'Enter your OAuth callback URL (leave empty to manually configure this value in the project\'s bootconfig file):',
            error: cli => val => 'Invalid value for callback URL: \'' + val + '\'.',
            validate: cli => val => val === undefined || val === '' || /\S+/.test(val),
            required: false,
            type: 'string'
        },
        loginServer: {
            name: 'loginserver',
            'char': 'l',
            description: 'Login server URL for the Salesforce org',
            longDescription: 'The login server URL for your Salesforce org (e.g. https://login.salesforce.com, https://test.salesforce.com, or custom domain). When provided, this will be automatically configured in the generated app.',
            prompt: 'Enter your login server URL (leave empty for https://login.salesforce.com):',
            error: cli => val => 'Invalid value for login server: \'' + val + '\'.',
            validate: cli => val => val === undefined || val === '' || /\S+/.test(val),
            required: false,
            type: 'string'
        }
    },

    commands: {
        create: {
            name: 'create',
            args: cli => [cli.platforms.length > 1 ? 'platform' : null,
                          cli.appTypes.length > 1 ? 'appType' : null,
                          'appName',
                          'packageName',
                          'organization',
                          cli.appTypes.indexOf('hybrid_remote') >=0 ? 'startPage' : null,
                          'outputDir',
                          'consumerKey',
                          'callbackURL',
                          'loginServer',
                          'verbose',
                          cli.name === 'forcehybrid' ? 'pluginRepoUri' : null,
			  'sdkDependencies'
                         ].filter(x=>x!=null),
            description: cli => 'create ' + cli.purpose,
            longDescription: cli => 'Create ' + cli.purpose + '.',
            help: 'This command initiates creation of a new app based on the standard Mobile SDK template.'
        },
        createwithtemplate: {
            name: 'createwithtemplate',
            args: cli => [cli.platforms.length > 1 ? 'platform' : null,
                          'templateSource',
                          'templateRepoUri',
                          'template',
                          'appName',
                          'packageName',
                          'organization',
                          cli.appTypes.indexOf('hybrid_remote') >=0 ? 'startPage' : null,
                          'outputDir',
                          'consumerKey',
                          'callbackURL',
                          'loginServer',
                          'verbose',
                          cli.name === 'forcehybrid' ? 'pluginRepoUri' : null,
                          'sdkDependencies'              
                         ].filter(x=>x!=null),
            description: cli => 'create ' + cli.purpose + ' from a template',
            longDescription: cli => 'Create ' + cli.purpose + ' from a template.',
            help: 'This command initiates creation of a new app based on the Mobile SDK template that you specify. The template can be a specialized app for your app type that Mobile SDK provides, or your own custom app that you\'ve configured to use as a template. See https://developer.salesforce.com/docs/atlas.en-us.mobile_sdk.meta/mobile_sdk/ios_new_project_template.htm for information on custom templates.',
            supportCustomFlags: true
        },
        version: {
            name: 'version',
            args: [],
            description: 'show version of Mobile SDK',
            longDescription: 'Show version of Mobile SDK.',
            help: 'This command displays to the console the version of Mobile SDK that the script uses to create apps.'
        },
        listtemplates: {
            name: 'listtemplates',
            args: ['templateSource', 'doc', 'json'],
            description: cli => 'list available Mobile SDK templates to create ' + cli.purpose,
            longDescription: cli => 'List available Mobile SDK templates to create ' + cli.purpose + '.',
            help: 'This command displays the list of available Mobile SDK templates. You can copy repo paths from the output for use with the createwithtemplate command. Use --templatesource to specify a custom template repository or leave blank to use the default template repository. Use --doc to include detailed metadata from template.json files (displayName, description, useCase, features, complexity). Use --json to output the response in JSON format.'
        },
        describetemplate: {
            name: 'describetemplate',
            args: ['templateSource', 'template', 'doc', 'json'],
            description: cli => 'list details for a specific Mobile SDK template to create ' + cli.purpose,
            longDescription: cli => 'List details for a specific Mobile SDK template to create ' + cli.purpose + '.',
            help: 'This command displays detailed information about a specific Mobile SDK template. Use --templatesource to specify a custom template repository or leave blank to use the default template repository. Use --template to specify the template name. Use --doc to include verbose metadata from template.json files. Use --json to output the response in JSON format.'
        },
        checkconfig: {
            name: 'checkconfig',
            args: ['configPath', 'configType'],
            description: 'validate store or syncs configuration',
            longDescription: 'Validate store or syncs configuration against their JSON schema.',
            help: 'This command checks whether the given store or syncs configuration is valid according to its JSON schema.'
        }
    }
};
